## Assignment 5
### Submission No - 128548
Algorithms :
1. Logistic Regression
2. Gaussian Naive Bayes
3. Decision Tree
4. Random Forest
    
Best Reported Algorithm - Random Forest with 99.9 % accuracy 
